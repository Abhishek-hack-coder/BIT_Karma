<?php
echo 
    '<footer class="ftco-footer ftco-section img">
            <div class="container-fluid px-md-5">
                <div class="row mb-5">
                    <div class="col-md">
                        <div class="ftco-footer-widget mb-4">
                            <h2 class="ftco-heading-2">AAYE</h2>
                            <p>Appointment At Your Ease.</p>
                            <ul class="ftco-footer-social list-unstyled mt-5">
                                <li class="ftco-animate">
                                    <a href="#" class="btn btn-secondary">
                                        <span class="icon-twitter"></span>
                                    </a>
                                </li>
                                <li class="ftco-animate">
                                    <a href="#" class="btn btn-secondary">
                                        <span class="icon-facebook"></span>
                                    </a>
                                </li>
                                <li class="ftco-animate">
                                    <a href="#" class="btn btn-secondary">
                                        <span class="icon-instagram"></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- loader -->
        <div id="ftco-loader" class="show fullscreen">
            <svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg>
        </div>';
?>